<?php
include('../connect.php');
// $servername = "localhost";
// $username = "root";
// $password = "";
// $dbname = "d_database";

// $con=mysqli_connect($servername, $username, $password, $dbname);


//  if($con){

// }else{
// 	echo "Not access";
// }
?>