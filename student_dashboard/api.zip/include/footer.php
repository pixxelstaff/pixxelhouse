<div class="py-6 px-6 text-center text-bg-primary rounded mt-3">
          <p class="mb-0 fs-4 p-3">Design and Developed by <a href="#" target="_blank" class="pe-1 text-white text-decoration-underline">Pixxel House</a></p>
        </div>